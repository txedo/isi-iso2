package dominio.conocimiento;

/**
 * Enumeraci�n con los roles que pueden tener los usuarios del sistema.
 */
public enum RolesUsuario {
	Administrador,
	Citador,
	M�dico
}
