package dominio.conocimiento;

/**
 * Interfaz que define las operaciones b�sicas de la clase Sesion.
 */
public interface ISesion {

	public long getId();
	
	public long getRol();
	
}
