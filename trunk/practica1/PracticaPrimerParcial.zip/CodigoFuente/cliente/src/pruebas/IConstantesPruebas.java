package pruebas;

/**
 * Interfaz con constantes utilizadas en las pruebas.
 */
public interface IConstantesPruebas {
	
	public static final String YES_OPTION = "S�";
	public static final String NO_OPTION = "No";
	public static final String CANCEL_OPTION = "Cancelar";
	public static final String OK_OPTION = "Aceptar";
	public static final String CLOSE_OPTION = "Cerrar";
	public static final String TITULO_VENTANA_ERROR = "Error";
	public static final int TIME_OUT = 1000;
	
}
