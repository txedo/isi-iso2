Nombres de usuario y contrase�as para acceder al sistema

admin -> admin123
adminaux -> adminaux9
citcr -> ciudadreal
cit77 -> passcit77
medpedro -> pedro700
medcab30 -> Cabecera
pedantonio -> antonio105
pedmari -> marissca
trmjose50 -> jose1900
cardio80 -> cardiologocr
neufelipe -> felipetoledo
neubelen -> belen2010
pedjaime -> unpediatra
pedpilar -> pilar777