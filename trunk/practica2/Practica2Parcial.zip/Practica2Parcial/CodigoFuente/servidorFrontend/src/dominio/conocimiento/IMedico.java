package dominio.conocimiento;

/**
 * Interfaz que define las operaciones b�sicas de la clase Medico.
 */
public interface IMedico {

	public String getNif();
	
}
