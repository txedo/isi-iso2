package dominio.conocimiento;

/**
 * Enumeraci�n con los tipos de m�dico que puede haber en el sistema.
 */
public enum CategoriasMedico {
	Cabecera,
	Pediatra,
	Especialista
}
