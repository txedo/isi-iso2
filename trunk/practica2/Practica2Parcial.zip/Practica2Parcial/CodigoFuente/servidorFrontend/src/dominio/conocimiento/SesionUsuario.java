package dominio.conocimiento;

import java.io.Serializable;

/**
 * Clase que representa una sesi�n iniciada por un usuario del sistema
 * en el servidor front-end.
 */
public class SesionUsuario extends Sesion implements Serializable {

	private static final long serialVersionUID = 7682926390745702387L;

	private Usuario usuario;
	
	public SesionUsuario(long idSesion, Usuario usuario) {
		super(idSesion);
		this.usuario = usuario;
	}

	public long getRol() {
		return usuario.getRol().ordinal();
	}
	
	public String getNombre() {
		return usuario.getLogin();
	}
	
	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public boolean equals(Object o) {
		SesionUsuario s;
		boolean dev;
		
		dev = false;
		if(o != null && o instanceof SesionUsuario) {
			s = (SesionUsuario)o;
			dev = super.equals(s) && getUsuario().equals(s.getUsuario());
		}
		return dev;
	}
	
}
