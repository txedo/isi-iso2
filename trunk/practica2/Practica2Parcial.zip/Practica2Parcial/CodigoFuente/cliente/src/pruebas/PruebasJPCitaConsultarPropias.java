package pruebas;

import java.util.Date;

import javax.swing.JTable;

import org.uispec4j.Button;
import org.uispec4j.Panel;
import org.uispec4j.Table;
import org.uispec4j.Trigger;
import org.uispec4j.Window;
import org.uispec4j.interception.WindowHandler;
import org.uispec4j.interception.WindowInterceptor;

import presentacion.JPCitaConsultarPropias;
import presentacion.auxiliar.OperacionesInterfaz;

import comunicaciones.ConfiguracionCliente;

import dominio.conocimiento.Beneficiario;
import dominio.conocimiento.Cabecera;
import dominio.conocimiento.Cita;
import dominio.conocimiento.DiaSemana;
import dominio.conocimiento.Direccion;
import dominio.conocimiento.IConstantes;
import dominio.conocimiento.Medico;
import dominio.conocimiento.PeriodoTrabajo;
import dominio.conocimiento.TipoMedico;
import dominio.control.ControladorCliente;

/**
 * Pruebas del panel de consulta de las citas propias del m�dico.
 */
public class PruebasJPCitaConsultarPropias extends org.uispec4j.UISpecTestCase implements IDatosConexionPruebas, IConstantesPruebas {

	private ControladorCliente controlador, controladorAuxiliar;
	private JPCitaConsultarPropias panel;
	private Panel pnlPanel;
	private Table tblCitas;
	private Button btnCitasHistorico;
	private JTable jtblCitas;
	private Window winPrincipal;
	
	private Medico cabecera;
	private TipoMedico tCabecera;
	private Beneficiario beneficiarioPrueba;
	
	private boolean beneficiarioEliminado;
		
	@SuppressWarnings("deprecation")
	protected void setUp() {

		beneficiarioEliminado = false;
		
		try {
			// Iniciamos sesion con un administrador
			controladorAuxiliar = UtilidadesPruebas.crearControladorAuxiliar(IDatosConexionPruebas.USUARIO_ADMIN, IDatosConexionPruebas.PASSWORD_ADMIN);
			
			// Creamos un m�dico de cabecera 
			tCabecera = new Cabecera();
			cabecera = new Medico();
			cabecera.setNombre("Eduardo");
			cabecera.setApellidos("Ram�rez Garc�a");
			cabecera.setTipoMedico(tCabecera);
			cabecera.getCalendario().add(new PeriodoTrabajo(10, 16, DiaSemana.Miercoles));
			cabecera = (Medico)UtilidadesPruebas.crearUsuario(controladorAuxiliar, cabecera); 

			// Creamos el beneficiario en el mismo centro que el m�dico, para que no se le asigne otro diferente 
			beneficiarioPrueba = new Beneficiario();
			beneficiarioPrueba.setNombre("beneficiario");
			beneficiarioPrueba.setApellidos("de prueba");
			beneficiarioPrueba.setCorreo(" ");
			beneficiarioPrueba.setTelefono(" ");
			beneficiarioPrueba.setMovil(" ");
			beneficiarioPrueba.setFechaNacimiento(new Date("01/01/1980"));
			beneficiarioPrueba.setDireccion(new Direccion("lagasca", "", "", "", "Madrid", "Madrid", 28000));
			beneficiarioPrueba.setCentroSalud(cabecera.getCentroSalud());
			beneficiarioPrueba.setMedicoAsignado(cabecera);
			beneficiarioPrueba = UtilidadesPruebas.crearBeneficiario(controladorAuxiliar, beneficiarioPrueba);
			
			// Iniciamos sesion con el m�dico de cabecera de prueba que hemos creado
			controlador = new ControladorCliente();
			winPrincipal = WindowInterceptor.run(new Trigger() {
				public void run() {
					try {
						controlador.iniciarSesion(new ConfiguracionCliente(IP_SERVIDOR_FRONTEND, PUERTO_SERVIDOR_FRONTEND), cabecera.getLogin(), cabecera.getLogin());
					} catch(Exception e) {
						fail(e.toString());
					}
				}
			});
			// Indicamos que la operaci�n activa del m�dico es la de consultar las citas propias de un m�dico
			controlador.getVentanaPrincipal().setOperacionSeleccionada(OperacionesInterfaz.ConsultarCitasPropias);
			
			// Obtenemos el panel
			Panel p1 = winPrincipal.getPanel("jPanelGestionarCitas");
			panel = (JPCitaConsultarPropias)p1.getPanel("jPanelConsultarCitasPropias").getAwtContainer();

			// Obtenemos los componentes del panel
			pnlPanel = new Panel(panel);
			tblCitas = pnlPanel.getTable("tblTablaCitas");
			btnCitasHistorico = pnlPanel.getButton("btnCitasHistorico");		
			
			jtblCitas = (JTable) tblCitas.getAwtComponent();
		} catch(Exception e) {
			fail(e.toString());
		}
	}
	
	protected void tearDown() {
		try {
			// Borramos los usuarios y beneficiarios creados con la sesion del administrador
			controladorAuxiliar.eliminarMedico(cabecera);
			if (!beneficiarioEliminado) controladorAuxiliar.eliminarBeneficiario(beneficiarioPrueba);
			// Cerramos la sesi�n auxiliar de las pruebas del observador
			UtilidadesPruebas.cerrarControladorAuxiliar();
			// Cerramos la sesi�n y la ventana del controlador
			controlador.getVentanaPrincipal().dispose();
			controlador.cerrarSesion();
		} catch(Exception e) {
			fail(e.toString());
		}
	}
	
	public void testConsultarCitasVacias() {
		// Al abrir la ventana, como el m�dico no tiene citas asignadas, no habr� ninguna fila (ni en citas pendientes ni en el historico)
		btnCitasHistorico.click();
		assertTrue(tblCitas.getRowCount()==0);
	}
	
	@SuppressWarnings("deprecation")
	public void testConsultarCitas() {
		Cita c1 = null;
		
		try {
			// Registramos una cita futura de prueba (se necesita rol de administrador)
			c1= controladorAuxiliar.pedirCita(beneficiarioPrueba, cabecera.getNif(), new Date(2010-1900,5,16,10,IConstantes.DURACION_CITA), IConstantes.DURACION_CITA);

			// Consultamos la cita del medico del beneficiario
			btnCitasHistorico.click();
			// Para citas pendientes
			assertTrue(tblCitas.getRowCount()==1);
			assertEquals(tblCitas.getContentAt(0, 3), beneficiarioPrueba.getNif());
			btnCitasHistorico.click();
			// Para el historico
			assertTrue(tblCitas.getRowCount()==1);
			assertEquals(tblCitas.getContentAt(0, 3), beneficiarioPrueba.getNif());
		} catch (Exception e) {
			fail(e.toString());
		}
		
		try {
			// Borramos la cita (como administrador)
			controladorAuxiliar.anularCita(c1);
			btnCitasHistorico.click();
			assertTrue(tblCitas.getRowCount()==0);
		} catch (Exception e) {
			fail(e.toString());
		}
	}
	
	@SuppressWarnings("deprecation")
	public void testObservadorBeneficiario () {
		// Comprueba que cuando se actualiza o elimina un beneficiario desde un teminal,
		// las ventanas de otros terminales se actualizan correctamente
		Cita c1 = null;

		try {
			// Registramos una cita futura de prueba para el m�dico (se necesita rol de administrador)
			c1 = controladorAuxiliar.pedirCita(beneficiarioPrueba, cabecera.getNif(), new Date(2010-1900,5,16,10,IConstantes.DURACION_CITA), IConstantes.DURACION_CITA);
			
			// Consultamos las citas del m�dico, que debe ser una
			btnCitasHistorico.click();
			assertTrue(tblCitas.getRowCount()==1);
		
			// En este momento el administrador modifica el beneficiario de la cita
			WindowInterceptor.init(new Trigger() {
				public void run() throws Exception {
					beneficiarioPrueba.setNombre("Otro Nombre");
					controladorAuxiliar.modificarBeneficiario(beneficiarioPrueba);
				}
			}).process(new WindowHandler() {
				public Trigger process(Window window) {
					// Capturamos la ventana que avisa del cambio en el beneficiario
					return window.getButton(OK_OPTION).triggerClick();
				}
			}).run();
			// Dormimos el hilo en espera de la respuesta del servidor
			Thread.sleep(TIME_OUT);
			// La ventana del m�dico se ha debido actualizar con el nuevo nombre del beneficiario
			assertEquals(jtblCitas.getModel().getValueAt(0, 2), beneficiarioPrueba.getApellidos() + ", " + beneficiarioPrueba.getNombre());
			
			// Ahora eliminamos el beneficiario
			WindowInterceptor.init(new Trigger() {
				public void run() throws Exception {
					controladorAuxiliar.eliminarBeneficiario(beneficiarioPrueba);
				}
			}).process(new WindowHandler() {
				public Trigger process(Window window) {
					// Capturamos la ventana que avisa de la eliminaci�n del beneficiario
					return window.getButton(OK_OPTION).triggerClick();
				}
			}).run();
			// Dormimos el hilo en espera de la respuesta del servidor
			Thread.sleep(TIME_OUT);
			// La tabla de citas debe estar vac�a, pues se ha borrado el beneficiario de la cita
			assertEquals(tblCitas.getRowCount(),0);
			beneficiarioEliminado = true;
			// Borramos la cita de prueba
			try {
				controladorAuxiliar.anularCita(c1);
				fail ("ERROR: Al borrar el beneficiario, la cita deber�a haberse eliminado en cascada.");
			} catch (Exception e) {
				// Oraculo negativo, debe producirse esta excepcion para un funcionamiento correcto
			}
		} catch (Exception e) {
			fail (e.toString());
		}
	}
	
	public void testObservadorCitas() {
		try {
			// Consultamos las citas del m�dico, que no debe tener ninguna
			btnCitasHistorico.click();
			assertTrue(tblCitas.getRowCount()==0);
			// Pedimos una cita para este m�dico desde el controlador auxiliar
			WindowInterceptor.init(new Trigger() {
				@SuppressWarnings("deprecation")
				public void run() throws Exception {
					controladorAuxiliar.pedirCita(beneficiarioPrueba, beneficiarioPrueba.getMedicoAsignado().getNif(), new Date(2015-1900,3-1,4,10,IConstantes.DURACION_CITA), IConstantes.DURACION_CITA);
				}
			}).process(new WindowHandler() {
				public Trigger process(Window window) {
					// Capturamos la ventana que avisa de la nueva cita registrada
					return window.getButton(OK_OPTION).triggerClick();
				}
			}).run();
			Thread.sleep(TIME_OUT);
			// La tabla de citas se debe haber actualizado
			assertTrue(tblCitas.getRowCount()==1);
			assertEquals(jtblCitas.getModel().getValueAt(0, 3), beneficiarioPrueba.getNif());
		} catch(Exception e) {
			fail(e.toString());
		}
		
		try {
			// Ahora procedemos a eliminar la cita desde el segundo administrador
			WindowInterceptor.init(new Trigger() {
				@SuppressWarnings("deprecation")
				public void run() throws Exception {
					controladorAuxiliar.anularCita(new Cita(new Date(2015-1900,3-1,4,10,IConstantes.DURACION_CITA), IConstantes.DURACION_CITA, beneficiarioPrueba, beneficiarioPrueba.getMedicoAsignado()));
				}
			}).process(new WindowHandler() {
				public Trigger process(Window window) {
					// Capturamos la ventana que avisa de la anulaci�n de la cita
					return window.getButton(OK_OPTION).triggerClick();
				}
			}).run();
			Thread.sleep(TIME_OUT);
			// La tabla se debe haber quedado vacia
			assertTrue(tblCitas.getRowCount()==0);
		} catch(Exception e) {
			fail(e.toString());
		}
	}
	
}
